export const showDetails = [
    {
        id: "r1",
        title: "뮤지컬 라이온킹",
        image: "https://picsum.photos/400/560?random=1",
        date: "2024.03.01 - 2024.05.31",
        location: "예술의전당",
        price: "60,000원 ~ 140,000원",
        runningTime: "150분",
        age: "8세 이상",
        cast: "김OO, 이OO, 박OO",
        description: "브로드웨이 최고의 뮤지컬...",
        rating: 5
    },
    {
        id: "r2",
        title: "뮤지컬 위키드",
        image: "https://picsum.photos/400/560?random=2",
        date: "2024.04.01 - 2024.06.30",
        location: "블루스퀘어",
        price: "70,000원 ~ 150,000원",
        runningTime: "165분",
        age: "8세 이상",
        cast: "정OO, 최OO, 강OO",
        description: "브로드웨이의 대표적인 뮤지컬...",
        rating: 4
    }
    // ... 필요한 만큼 데이터 추가
];
