import React from 'react'

const Footer = () => {
    return (
        <footer id='footer' role="contentinfo"> 
            <p>©COPYRIGHT 2024 TICKET101</p>
        </footer>
    )
}

export default Footer
