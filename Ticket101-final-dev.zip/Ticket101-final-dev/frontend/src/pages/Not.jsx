import React from 'react'

const Not = () => {
    return (
        <div>Not</div>
    )
}
    
export default Not
